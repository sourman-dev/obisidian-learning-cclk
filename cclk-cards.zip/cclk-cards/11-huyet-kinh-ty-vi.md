---
topic: Huyệt vị Kinh Tỳ và Vị
chapter: 11
tags: [huyet-vi, kinh-ty, kinh-vi]
---

# Huyệt vị Kinh Tỳ và Vị

## KINH TÚC THÁI ÂM TỲ

## Ẩn Bạch - Vị trí
Q::: Huyệt Ẩn Bạch nằm ở đâu?
A::: Góc trong ngón chân cái, cách móng chân 0,1 thốn.

## Ẩn Bạch - Phân loại
Q::: Huyệt Ẩn Bạch thuộc loại huyệt gì trên Kinh Tỳ?
A::: Huyệt Tĩnh (huyệt đầu tiên của kinh).

## Ẩn Bạch - Ngũ hành
Q::: Huyệt Ẩn Bạch mang hành gì?
A::: Hành Mộc.

## Đại Đô - Vị trí
Q::: Huyệt Đại Đô nằm ở đâu?
A::: Bờ trong xương ngón cái, trên đường tiếp giáp lằn da gan bàn chân dưới chỏm xương bàn chân.

## Đại Đô - Phân loại
Q::: Huyệt Đại Đô thuộc loại huyệt gì trên Kinh Tỳ?
A::: Huyệt Vinh (huyệt thứ hai của kinh).

## Đại Đô - Ngũ hành
Q::: Huyệt Đại Đô mang hành gì?
A::: Hành Hỏa.

## Thái Bạch - Vị trí
Q::: Huyệt Thái Bạch nằm ở đâu?
A::: Chỗ lõm bờ trong bàn chân, phía sau và dưới đầu xương bàn chân 1.

## Thái Bạch - Phân loại
Q::: Huyệt Thái Bạch thuộc loại huyệt gì trên Kinh Tỳ?
A::: Huyệt Du và Nguyên (huyệt thứ ba, cũng là huyệt nguyên).

## Thái Bạch - Ngũ hành
Q::: Huyệt Thái Bạch mang hành gì?
A::: Hành Thổ.

## Thương Khâu - Vị trí
Q::: Huyệt Thương Khâu nằm ở đâu?
A::: Chỗ lõm phía trước mắt cá chân trong, giữa gân cơ cẳng chân sau và khớp sên-thuyền.

## Thương Khâu - Phân loại
Q::: Huyệt Thương Khâu thuộc loại huyệt gì trên Kinh Tỳ?
A::: Huyệt Kinh (huyệt thứ tư của kinh).

## Thương Khâu - Ngũ hành
Q::: Huyệt Thương Khâu mang hành gì?
A::: Hành Kim.

## Âm Lăng Tuyền - Vị trí
Q::: Huyệt Âm Lăng Tuyền nằm ở đâu?
A::: Chỗ lõm bờ sau trong đầu trên xương chày, cách nếp gấp đầu gối 2,5 thốn.

## Âm Lăng Tuyền - Phân loại
Q::: Huyệt Âm Lăng Tuyền thuộc loại huyệt gì trên Kinh Tỳ?
A::: Huyệt Hợp (huyệt thứ năm của kinh).

## Âm Lăng Tuyền - Ngũ hành
Q::: Huyệt Âm Lăng Tuyền mang hành gì?
A::: Hành Thủy.

## KINH TÚC DƯƠNG MINH VỊ

## Lệ Đoài - Vị trí
Q::: Huyệt Lệ Đoài nằm ở đâu?
A::: Ngoài ngón chân thứ 2, cách góc móng chân 0,1 thốn.

## Lệ Đoài - Phân loại
Q::: Huyệt Lệ Đoài thuộc loại huyệt gì trên Kinh Vị?
A::: Huyệt Tĩnh (huyệt đầu tiên của kinh).

## Lệ Đoài - Ngũ hành
Q::: Huyệt Lệ Đoài mang hành gì?
A::: Hành Kim.

## Nội Đình - Vị trí
Q::: Huyệt Nội Đình nằm ở đâu?
A::: Giữa kẽ ngón chân 2-3.

## Nội Đình - Phân loại
Q::: Huyệt Nội Đình thuộc loại huyệt gì trên Kinh Vị?
A::: Huyệt Vinh (huyệt thứ hai của kinh).

## Nội Đình - Ngũ hành
Q::: Huyệt Nội Đình mang hành gì?
A::: Hành Thủy.

## Hãm Cốc - Vị trí
Q::: Huyệt Hãm Cốc nằm ở đâu?
A::: Giữa kẽ ngón chân 2-3, đo lên 2 thốn về phía mu chân.

## Hãm Cốc - Phân loại
Q::: Huyệt Hãm Cốc thuộc loại huyệt gì trên Kinh Vị?
A::: Huyệt Du (huyệt thứ ba của kinh).

## Hãm Cốc - Ngũ hành
Q::: Huyệt Hãm Cốc mang hành gì?
A::: Hành Mộc.

## Xung Dương - Vị trí
Q::: Huyệt Xung Dương nằm ở đâu?
A::: Dưới huyệt Giải Khê 1,5 thốn, nơi cao nhất mu bàn chân có động mạch đập.

## Xung Dương - Phân loại
Q::: Huyệt Xung Dương thuộc loại huyệt gì trên Kinh Vị?
A::: Huyệt Nguyên (huyệt nguyên của kinh).

## Xung Dương - Ngũ hành
Q::: Huyệt Xung Dương mang hành gì?
A::: Hành Mộc.

## Giải Khê - Vị trí
Q::: Huyệt Giải Khê nằm ở đâu?
A::: Trên nếp gấp cổ chân giữa 2 gân cơ cẳng chân trước và gân cơ duỗi dài ngón cái.

## Giải Khê - Phân loại
Q::: Huyệt Giải Khê thuộc loại huyệt gì trên Kinh Vị?
A::: Huyệt Kinh (huyệt thứ tư của kinh).

## Giải Khê - Ngũ hành
Q::: Huyệt Giải Khê mang hành gì?
A::: Hành Hỏa.

## Túc Tam Lý - Vị trí
Q::: Huyệt Túc Tam Lý nằm ở đâu?
A::: Dưới mắt gối ngoài 3 thốn, cách mào xương chày 1 khoát ngón tay.

## Túc Tam Lý - Phân loại
Q::: Huyệt Túc Tam Lý thuộc loại huyệt gì trên Kinh Vị?
A::: Huyệt Hợp (huyệt thứ năm của kinh).

## Túc Tam Lý - Ngũ hành
Q::: Huyệt Túc Tam Lý mang hành gì?
A::: Hành Thổ.

## Matching: Ngũ du huyệt Kinh Tỳ
MATCH::
- Ẩn Bạch | Tĩnh
- Đại Đô | Vinh
- Thái Bạch | Du + Nguyên
- Thương Khâu | Kinh
- Âm Lăng Tuyền | Hợp

## Matching: Ngũ hành Kinh Tỳ
MATCH::
- Ẩn Bạch | Mộc
- Đại Đô | Hỏa
- Thái Bạch | Thổ
- Thương Khâu | Kim
- Âm Lăng Tuyền | Thủy

## Matching: Ngũ du huyệt Kinh Vị
MATCH::
- Lệ Đoài | Tĩnh
- Nội Đình | Vinh
- Hãm Cốc | Du
- Xung Dương | Nguyên
- Giải Khê | Kinh
- Túc Tam Lý | Hợp

## Matching: Ngũ hành Kinh Vị
MATCH::
- Lệ Đoài | Kim
- Nội Đình | Thủy
- Hãm Cốc | Mộc
- Xung Dương | Mộc
- Giải Khê | Hỏa
- Túc Tam Lý | Thổ
