---
topic: Huyệt vị Kinh Can và Đởm
chapter: 12
tags: [huyet-vi, kinh-can, kinh-dom]
---

# Huyệt vị Kinh Can và Đởm

## KINH TÚC QUYẾT ÂM CAN

## Đại Đôn - Vị trí
Q::: Huyệt Đại Đôn nằm ở đâu?
A::: Cách bờ ngoài gốc móng chân ngón cái 0,1 thốn.

## Đại Đôn - Phân loại
Q::: Huyệt Đại Đôn thuộc loại huyệt gì trên Kinh Can?
A::: Huyệt Tĩnh (huyệt đầu tiên của kinh).

## Đại Đôn - Ngũ hành
Q::: Huyệt Đại Đôn mang hành gì?
A::: Hành Mộc.

## Hành Gian - Vị trí
Q::: Huyệt Hành Gian nằm ở đâu?
A::: Kẽ ngón chân 1 và 2 đo lên 0,5 thốn về phía mu chân.

## Hành Gian - Phân loại
Q::: Huyệt Hành Gian thuộc loại huyệt gì trên Kinh Can?
A::: Huyệt Vinh (huyệt thứ hai của kinh).

## Hành Gian - Ngũ hành
Q::: Huyệt Hành Gian mang hành gì?
A::: Hành Hỏa.

## Thái Xung - Vị trí
Q::: Huyệt Thái Xung nằm ở đâu?
A::: Giữa kẽ ngón chân 1 và 2 đo lên 2 thốn về phía mu chân.

## Thái Xung - Phân loại
Q::: Huyệt Thái Xung thuộc loại huyệt gì trên Kinh Can?
A::: Huyệt Du và Nguyên (huyệt thứ ba, cũng là huyệt nguyên).

## Thái Xung - Ngũ hành
Q::: Huyệt Thái Xung mang hành gì?
A::: Hành Thổ.

## Trung Phong - Vị trí
Q::: Huyệt Trung Phong nằm ở đâu?
A::: Bờ dưới mắt cá trong khoảng 1 thốn, điểm lõm giữa cơ dài ngón cái và cơ chày trước.

## Trung Phong - Phân loại
Q::: Huyệt Trung Phong thuộc loại huyệt gì trên Kinh Can?
A::: Huyệt Kinh (huyệt thứ tư của kinh).

## Trung Phong - Ngũ hành
Q::: Huyệt Trung Phong mang hành gì?
A::: Hành Kim.

## Khúc Tuyền - Vị trí
Q::: Huyệt Khúc Tuyền nằm ở đâu?
A::: Khi gấp chân lại, huyệt nằm phía trong xương đùi đầu nếp gấp đầu gối.

## Khúc Tuyền - Phân loại
Q::: Huyệt Khúc Tuyền thuộc loại huyệt gì trên Kinh Can?
A::: Huyệt Hợp (huyệt thứ năm của kinh).

## Khúc Tuyền - Ngũ hành
Q::: Huyệt Khúc Tuyền mang hành gì?
A::: Hành Thủy.

## KINH TÚC THIẾU DƯƠNG ĐỞM

## Túc Khiếu Âm - Vị trí
Q::: Huyệt Túc Khiếu Âm nằm ở đâu?
A::: Bên ngoài ngón chân thứ 4, cách góc móng chân 0,1 thốn.

## Túc Khiếu Âm - Phân loại
Q::: Huyệt Túc Khiếu Âm thuộc loại huyệt gì trên Kinh Đởm?
A::: Huyệt Tĩnh (huyệt đầu tiên của kinh).

## Túc Khiếu Âm - Ngũ hành
Q::: Huyệt Túc Khiếu Âm mang hành gì?
A::: Hành Kim.

## Hiệp Khê - Vị trí
Q::: Huyệt Hiệp Khê nằm ở đâu?
A::: Khe giữa xương bàn chân ngón 4 và 5, đầu kẽ giữa 2 ngón chân, phía mu chân.

## Hiệp Khê - Phân loại
Q::: Huyệt Hiệp Khê thuộc loại huyệt gì trên Kinh Đởm?
A::: Huyệt Vinh (huyệt thứ hai của kinh).

## Hiệp Khê - Ngũ hành
Q::: Huyệt Hiệp Khê mang hành gì?
A::: Hành Thủy.

## Túc Lâm Khấp - Vị trí
Q::: Huyệt Túc Lâm Khấp nằm ở đâu?
A::: Chỗ lõm phía trước khớp xương bàn ngón chân 4-5.

## Túc Lâm Khấp - Phân loại
Q::: Huyệt Túc Lâm Khấp thuộc loại huyệt gì trên Kinh Đởm?
A::: Huyệt Du (huyệt thứ ba của kinh).

## Túc Lâm Khấp - Ngũ hành
Q::: Huyệt Túc Lâm Khấp mang hành gì?
A::: Hành Mộc.

## Khâu Khư - Vị trí
Q::: Huyệt Khâu Khư nằm ở đâu?
A::: Phía trước và dưới mắt cá ngoài, chỗ lõm giữa huyệt Thân Mạch và Giải Khê.

## Khâu Khư - Phân loại
Q::: Huyệt Khâu Khư thuộc loại huyệt gì trên Kinh Đởm?
A::: Huyệt Nguyên (huyệt nguyên của kinh).

## Khâu Khư - Ngũ hành
Q::: Huyệt Khâu Khư mang hành gì?
A::: Hành Mộc.

## Dương Phụ - Vị trí
Q::: Huyệt Dương Phụ nằm ở đâu?
A::: Trên đỉnh mắt cá ngoài 4 thốn, ở bờ dưới xương mác.

## Dương Phụ - Phân loại
Q::: Huyệt Dương Phụ thuộc loại huyệt gì trên Kinh Đởm?
A::: Huyệt Kinh (huyệt thứ tư của kinh).

## Dương Phụ - Ngũ hành
Q::: Huyệt Dương Phụ mang hành gì?
A::: Hành Hỏa.

## Dương Lăng Tuyền - Vị trí
Q::: Huyệt Dương Lăng Tuyền nằm ở đâu?
A::: Chỗ lõm phía trước và dưới đầu nhỏ xương mác.

## Dương Lăng Tuyền - Phân loại
Q::: Huyệt Dương Lăng Tuyền thuộc loại huyệt gì trên Kinh Đởm?
A::: Huyệt Hợp (huyệt thứ năm của kinh).

## Dương Lăng Tuyền - Ngũ hành
Q::: Huyệt Dương Lăng Tuyền mang hành gì?
A::: Hành Thổ.

## Matching: Ngũ du huyệt Kinh Can
MATCH::
- Đại Đôn | Tĩnh
- Hành Gian | Vinh
- Thái Xung | Du + Nguyên
- Trung Phong | Kinh
- Khúc Tuyền | Hợp

## Matching: Ngũ hành Kinh Can
MATCH::
- Đại Đôn | Mộc
- Hành Gian | Hỏa
- Thái Xung | Thổ
- Trung Phong | Kim
- Khúc Tuyền | Thủy

## Matching: Ngũ du huyệt Kinh Đởm
MATCH::
- Túc Khiếu Âm | Tĩnh
- Hiệp Khê | Vinh
- Túc Lâm Khấp | Du
- Khâu Khư | Nguyên
- Dương Phụ | Kinh
- Dương Lăng Tuyền | Hợp

## Matching: Ngũ hành Kinh Đởm
MATCH::
- Túc Khiếu Âm | Kim
- Hiệp Khê | Thủy
- Túc Lâm Khấp | Mộc
- Khâu Khư | Mộc
- Dương Phụ | Hỏa
- Dương Lăng Tuyền | Thổ
